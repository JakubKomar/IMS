# IMS
IMS projekt - doprava LNG

Simulator of IMS project: LNG infrastruktura
usege: ims [args]
args:
    -h (--help)                             : help
    -m (--malfunction)              : malfuction , 0 disables malfunctions
    -t (--tankers)                  : tankers count
    -U (--usterminals)              : US count of terminals
    -G (--geterminals)              : German count of terminals
    -R (--TRMP)                             : propability of reapaireble mallfuction on every tanker
    -F (--TFMP)                             : propability of fatal mallfuction on every tanker
    -s (--simTime)                  : sim time in years
    -c (--tankerCapacity)   : capacity of single tanker